package com.capgemini.go.product.dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import com.capgemini.go.product.entity.Product;

public class ProductDTO {

	@Pattern(regexp = "P[0-9]{5}", message = "Id starts with P and have 5 characters")
	String productId;
	
	@Size(min = 5, message = "Name should have atleast 5 characters")
	@Pattern(regexp = "[A-Z].*", message = "Product name starts with capital letter")
	String productName;
	
	@Size(min = 5, message = "Name should have atleast 5 characters")
	@Pattern(regexp = "[A-Z].*", message = "Category starts with capital letter")
	String category;
	
	@Size(min = 5, message = "Name should have atleast 5 characters")
	@Pattern(regexp = "[A-Z].*", message = "Description starts with capital letter")
	String description;
	
	double price;

	@Pattern(regexp = "[A-Z].*", message = "Manufacturer starts with capital letter")
	String manufacturer;

	public ProductDTO()
	{
		
	}

	public ProductDTO(String productId, String productName, String category, String description, double price,
			String manufacturer) {
		super();
		this.productId = productId;
		this.productName = productName;
		this.category = category;
		this.description = description;
		this.price = price;
		this.manufacturer = manufacturer;
	}

	public ProductDTO(String productName, String category, String description, double price, String manufacturer) {
		super();

		this.productName = productName;
		this.category = category;
		this.description = description;
		this.price = price;
		this.manufacturer = manufacturer;
	}
	public ProductDTO(Product product)
	{
		this.productId=product.getProductId();
		this.productName=product.getProductName();
		this.description=product.getDescription();
		this.category=product.getCategory();
		this.price=product.getPrice();
		this.manufacturer=product.getManufacturer();
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", category=" + category
				+ ", description=" + description + ", price=" + price + ", manufacturer=" + manufacturer + "]";
	}

}
