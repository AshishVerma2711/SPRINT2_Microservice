package com.capgemini.go.entities;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="image_table")
public class Image {

	@Id
	private String productId;
	
	private byte[] image;

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public byte[] getImage() {
		return image;
	}

	public void setImage(byte[] img) {
		this.image = img;
	}

	public Image(String productId, byte[] img) {
		super();
		this.productId = productId;
		this.image = img;
	}

	public Image() {
		super();
		
	}
	
	
}
