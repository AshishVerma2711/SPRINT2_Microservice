package com.capgemini.go.controllers;

import org.springframework.http.HttpStatus;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.go.dto.OrderDTO;
import com.capgemini.go.entities.OrderEntity;
import com.capgemini.go.entities.OrderItemEntity;
import com.capgemini.go.service.OrderService;

import io.swagger.annotations.Api;

@RestController
@Api
@CrossOrigin("*")
public class OrderController {
	@Autowired
	OrderService orderService;
	
	
	@GetMapping(value="/user/order/{orderId}")
	public ResponseEntity<OrderDTO> getOrderById(@PathVariable("orderId") String orderId)
	{
		
		return new ResponseEntity<>(orderService.viewOrderDetails(orderId),HttpStatus.OK);
	}
	
	@GetMapping(value = "/admin/orders")
	public ResponseEntity<List<OrderEntity>> getAllOrders()
	{
		return new ResponseEntity<>(orderService.findAllOrders(),HttpStatus.OK);
	}
	
	@GetMapping(value = "/user/orders/{userId}")
	public ResponseEntity<List<OrderEntity>> getAllOrdersForUser(@PathVariable("userId") String userId )
	{
		return new ResponseEntity<>(orderService.findAllOrdersForUser(userId),HttpStatus.OK);
	}
	
	
	@GetMapping(value="/user/order/products/{orderId}")
	public ResponseEntity<List<OrderItemEntity>> getAllProductsInOrder(@PathVariable("orderId")String orderId)
	{
		return new ResponseEntity<>(orderService.getAllProductsInOrder(orderId),HttpStatus.OK);
	}
	
	
	@PostMapping(value="/user/order/")
	public ResponseEntity<String> placeOrder(@RequestBody String userId)
	{
		return new ResponseEntity<>(orderService.placeOrder(userId),HttpStatus.OK);
	}
	
	@GetMapping(value="/user/order/status/{orderID}")
	public ResponseEntity<String> getOrderStatus(@PathVariable("orderID") String orderId)
	{
		return new ResponseEntity<>(orderService.getOrderStatus(orderId),HttpStatus.OK);
	}
	
	@PutMapping(value="/admin/order/status/")
	public void updateStatus(@RequestBody Map<String, String> orderStatus)
	{
		System.out.println("Changed Status");
		orderService.changeStatusOfOrder(orderStatus.get("orderId"),orderStatus.get("status"));
	}
	
	@PutMapping(value="/user/order/products/")
	public ResponseEntity<String> deleteOrderItem(@RequestBody Map<String, String> orderItem)
	{
		return new ResponseEntity<>(orderService.deleteOrderItem(orderItem.get("orderId"),orderItem.get("productId")),HttpStatus.OK);
	}
	
	
}
