insert into cart values(1,'p10001',2,'u10001');
insert into cart values(2,'p10002',3,'u10001');
insert into cart values(3,'p10003',4,'u10002');
insert into cart values(4,'p10001',3,'u10001');
insert into cart values(6,'p10001',3,'u10001');

