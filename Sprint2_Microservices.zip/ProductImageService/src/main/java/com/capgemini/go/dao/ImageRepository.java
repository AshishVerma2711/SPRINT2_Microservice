package com.capgemini.go.dao;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.go.entities.Image;

@Repository
public interface ImageRepository extends CrudRepository<Image, String> {

}
