package com.capgemini.go.product.controller;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.Pattern;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.go.product.dto.ProductDTO;
import com.capgemini.go.product.service.ProductService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;

@RestController
@Api("Product Management Service")
@Validated
@CrossOrigin(origins = "*")
public class ProductController {

	@Autowired
	ProductService productService;
	Logger logger = LoggerFactory.getLogger(ProductController.class);

	@GetMapping(value = "/product/{productId}", produces = "application/json")
	@ApiOperation(value = "Get A Product by ID")
	public ResponseEntity<ProductDTO> getProductById(@PathVariable String productId) {
		return new ResponseEntity<>(productService.getProductById(productId), HttpStatus.OK);
	}
	
	@GetMapping(value = "/productList", produces = "application/json")
	@ApiOperation(value = "Get A Product List")
	public ResponseEntity<List<ProductDTO>> getProductList() {
		List<ProductDTO> productList = null;
		productList = productService.getProductList();
		logger.info("Return the Product List Successfully");
		return new ResponseEntity<>(productList, HttpStatus.OK);
	}

	@PostMapping(value = "/productList", consumes = "application/json", produces = "application/json")
	@ApiOperation(value = "Add a new Product in the list")
	public ResponseEntity<ProductDTO> addProduct(@Valid @ApiParam(value="ProductDto in json format")@RequestBody ProductDTO productDto) {
		ProductDTO addproduct = productService.addProduct(productDto);
		logger.info("Product Added Successfully");
		return new ResponseEntity<>(addproduct, HttpStatus.OK);
	}

	@DeleteMapping(path = { "/productList/{productId}" })
	@ApiOperation(value = "Delete a Product from the Product list")
	public void deleteProduct( @ApiParam(value="Product id through which the product is deleted")@PathVariable("productId") @Pattern(regexp = "P[0-9]{5}", message = "Id starts with P and have 5 characters") String productId) {

		productService.deleteProductById(productId);
		logger.info("Product deleted Successfully");
		
	}

	@PutMapping(path = { "/productList" })
	@ApiOperation(value = "Update a Product in a Product list")
	public ResponseEntity<ProductDTO> updateProduct(@Valid @ApiParam(value="ProductDto in json format")@RequestBody ProductDTO productDto) {
		ProductDTO updateproduct = productService.updateProduct(productDto.getProductId(), productDto);
		logger.info("Product Updated Successfully");
		return new ResponseEntity<>(updateproduct, HttpStatus.OK);
	}

	@GetMapping(value = "/productList/{productName}", produces = "application/json")
	@ApiOperation(value = "Search a Product by product Name")
	public ResponseEntity<ProductDTO> getByProductName( @ApiParam(value="search by product name")@PathVariable("productName") @Pattern(regexp = "[A-Z].*", message = "Product name starts with capital letter") String productName) {
		ProductDTO product = productService.getProduct(productName);
		logger.info("return the product");
		return new ResponseEntity<>(product, HttpStatus.OK);
	}
	
	@PostMapping(value = "/getProductsList",produces = "application/json")
	@ApiOperation(value = "get a product name List")
	public ResponseEntity<List<ProductDTO>> getProductsList( @RequestBody List<String> productIdsList) {
		List<ProductDTO> productsList = productService.getProductsList(productIdsList);
		return new ResponseEntity<>(productsList,HttpStatus.OK);
	}
	
	@GetMapping(value = "/productList/price/{productId}", produces = "application/json")
	@ApiOperation(value = "get price by product Id")
	public ResponseEntity<Double> getPriceByProductId(@ApiParam(value="get price by product Id")@PathVariable("productId")String productId)
	{
		return new ResponseEntity<>(productService.getPriceByProductId(productId),HttpStatus.OK);
	}
	
	@GetMapping(value = "/products/search")
	public List<ProductDTO> searchProducts(@RequestParam Optional<String> productName)
	{	
		return productService.searchProducts(productName.orElse("_"));
	}

}
