package com.capgemini.go.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.capgemini.go.dao.AuthUserDetails;
import com.capgemini.go.dao.LoginRepository;
import com.capgemini.go.dto.Login;

@Service
public class AuthUserDetailsService implements UserDetailsService{

	@Autowired
	private LoginRepository loginRepository;
	
	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		Optional<Login> login = loginRepository.findByUserName(userName);
		return login.map(AuthUserDetails::new).get();
	}
}
