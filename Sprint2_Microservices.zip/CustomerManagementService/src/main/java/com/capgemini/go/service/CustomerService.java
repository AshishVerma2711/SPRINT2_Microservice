package com.capgemini.go.service;

import java.util.List;
import java.util.Optional;

import com.capgemini.go.entity.Customer;

public interface CustomerService {
	
	List<Customer> getAllCustomers();
	Optional<Customer> getCustomerByUserId(String userId);
	Customer addCustomer(Customer user);
	Customer updateCustomer(Customer user);
	List<String> getAllCustomerUserIds();

}
