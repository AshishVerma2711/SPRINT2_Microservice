package com.capgemini.go.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.go.dto.CartDTO;
import com.capgemini.go.dto.CartId;
import com.capgemini.go.exception.ResourceNotFoundException;
import com.capgemini.go.service.CartService;

@RestController
@CrossOrigin("*")
public class CartController {

	@Autowired
	private CartService cartService;
	
	
	
	//***********************Get All items List of a userId Cart************************
	
	
	
	@GetMapping("/user/cart/{userId}")
	
	public List<CartDTO> getAllCartItemsList( @PathVariable String userId)
	{
		if(cartService.getAllCartItemsList(userId).size()==0)
		{
			throw new ResourceNotFoundException("user not found with id "+userId);
		}
		return cartService.getAllCartItemsList(userId);
		
	}
	

	//***********************Add item into Cart List************************
	
	
	
	
	@PostMapping(
			  value = "/user/cart/addItem", 
			  produces = "application/json")
	
	public CartDTO addItemIntoCart(@RequestBody CartDTO addThisItem)
	{
		CartDTO addedItem=cartService.addItemIntoCart(addThisItem);
		
		if(addedItem==null)
		{
			throw new ResourceNotFoundException("Add to cart Failed");
		}
		return addedItem;
		
	}
	
	
	
	
	//***********************Remove item from a Cart List************************
	
	
	@PostMapping(
			  value = "/user/cart/", 
			  produces = "application/json")
	
	public void removeItemfromCart(@RequestBody CartId cartId)
	{
		 cartService.removeItemfromCart(cartId);
		
	}
	
	@GetMapping(value = "/user/cartValue/{userId}")
	public double getCartValue(@PathVariable("userId")String userId)
	{
		System.out.println(userId);
		return cartService.getCartValue(userId);
	}
}
