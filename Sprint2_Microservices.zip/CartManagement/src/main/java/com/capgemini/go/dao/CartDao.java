package com.capgemini.go.dao;
import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.capgemini.go.dto.CartDTO;
import com.capgemini.go.dto.CartId;


@Repository
public interface CartDao extends CrudRepository<CartDTO,CartId>
{
		public List<CartDTO> findAllByCartIdUserId(String userId);
}
