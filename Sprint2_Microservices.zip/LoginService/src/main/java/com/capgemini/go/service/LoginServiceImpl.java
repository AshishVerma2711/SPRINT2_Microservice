package com.capgemini.go.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.go.dao.LoginRepository;
import com.capgemini.go.dto.Login;

@Service
public class LoginServiceImpl implements LoginService{

	@Autowired
	private LoginRepository loginRepository;
	
	@Override
	public Login addCredentials(Login login) {
		return loginRepository.save(login);
	}
	

}
