package com.capgemini.go.product;


import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductManagementServiceApplicationTests {

	
}
