package com.capgemini.go.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.capgemini.go.dao.CartDao;
import com.capgemini.go.dto.CartDTO;
import com.capgemini.go.dto.CartId;
import com.capgemini.go.exception.ResourceNotFoundException;
@Service
public class CartServiceImpl implements CartService
{

	@Autowired
	private CartDao cartDao;
	
	@Autowired
	RestTemplate restTemplate;
	
	//***********************Get All items List of a userId Cart************************
	
	
	
	@Override
	public List<CartDTO> getAllCartItemsList(String userId) 
	{
		
		return cartDao.findAllByCartIdUserId(userId);
			
	}

	
	//***********************Add item into Cart List************************
	
	
	
	@Override
	public CartDTO addItemIntoCart(CartDTO addThisItem) 
	{
		
		return cartDao.save(addThisItem);
	}	
	
	
	
	//***********************Remove item from a Cart List************************
	

	@Override
	public String removeItemfromCart(CartId cartId) 
	{
		 if(cartDao.existsById(cartId))
		 {
			 cartDao.deleteById(cartId);
			 return "Item with Prodcut Id :"+ cartId.getProductId()+" deleted successfuly";
		 }
		 else
		 {
			 throw new ResourceNotFoundException("Not item Found");
		 }
	}


	@Override
	public double getCartValue(String userId) {
		List<CartDTO> cartItems= cartDao.findAllByCartIdUserId(userId);
		
		double cartValue=0;
		for(CartDTO cartItem:cartItems)
		{	
			cartValue+=(cartItem.getQuantity())*
					(restTemplate.getForEntity("http://ProductManagement-service/productList/price/"+cartItem.getCartId().getProductId(), Double.class).getBody());
		}
		return cartValue;
	}
	
}
