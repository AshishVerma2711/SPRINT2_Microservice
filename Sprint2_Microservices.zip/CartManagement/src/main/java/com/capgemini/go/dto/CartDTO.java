package com.capgemini.go.dto;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

import com.capgemini.go.dto.CartId;

@Entity
@Table(name="Cart")
public class CartDTO{
	
	@EmbeddedId
	private CartId cartId;
	private int quantity;
	
	public CartDTO() {
		super();
	}
	
	
	public CartDTO(CartId cartId, int quantity) {
		super();
		this.cartId = cartId;
		this.quantity = quantity;
	}

	public CartId getCartId() {
		return cartId;
	}

	public void setCartId(CartId cartId) {
		this.cartId = cartId;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
	
}