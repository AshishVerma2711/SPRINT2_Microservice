package com.capgemini.go.dao;

import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;

import com.capgemini.go.dto.Login;

public interface LoginRepository extends JpaRepository<Login,Integer>{
	Optional<Login> findByUserName(String userName);
}