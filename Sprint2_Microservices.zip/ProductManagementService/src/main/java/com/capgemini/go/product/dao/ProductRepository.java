package com.capgemini.go.product.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.capgemini.go.product.entity.Product;


public interface ProductRepository extends JpaRepository<Product, String> {

	public Product findByProductName(String productName);

	@Query(value = "select p.productId from Product p")
	public List<String> getAllProductId();
	
	@Query(value = "select p.price from Product p where p.productId= :productId")
	public double getPriceByProductId(@Param("productId")String productId);
	
	@Query(value = "SELECT p from Product p WHERE p.productName LIKE %?1%")
	public List<Product> searchProducts(String productName);

}
