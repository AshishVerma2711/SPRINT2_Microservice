package com.capgemini.go.service;

import com.capgemini.go.dto.Login;

public interface LoginService {

	Login addCredentials(Login login);

}
