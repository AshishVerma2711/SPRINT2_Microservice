INSERT INTO wishlist(user_id,product_id) VALUES ('U10001','P10001');
INSERT INTO wishlist(user_id,product_id) VALUES ('U10002','P10002');
INSERT INTO wishlist(user_id,product_id) VALUES ('U10001','P10003');
