package com.capgemini.go.product.service;

import java.util.List;

import com.capgemini.go.product.dto.ProductDTO;

public interface ProductService {

	public List<ProductDTO> getProductList();

	public ProductDTO addProduct(ProductDTO product);

	public void deleteProductById(String productId);

	public ProductDTO getProduct(String productName);

	public ProductDTO updateProduct(String productId, ProductDTO product);

	public List<ProductDTO> getProductsList(List<String> productIdsList);
	
	public double getPriceByProductId(String productId);
	
	public List<ProductDTO> searchProducts(String productName);
	
	public ProductDTO getProductById(String productId);

}
