package com.capgemini.go;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductImageServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
