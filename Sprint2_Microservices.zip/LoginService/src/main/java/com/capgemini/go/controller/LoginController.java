package com.capgemini.go.controller;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.go.dao.AuthUserDetails;
import com.capgemini.go.dto.Login;
import com.capgemini.go.service.LoginService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

@RestController
@RequestMapping("/loginApi")
@CrossOrigin(origins="*",allowedHeaders="*")
public class LoginController {
	
	Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	private LoginService loginService;
	
	@GetMapping("/authenticate")
	public Login authenticate(ModelMap model) {
		Login login = new Login();
		Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        AuthUserDetails userDetails = (AuthUserDetails)auth.getPrincipal();
        login.setUserId(userDetails.getUserId());
        login.setUserName(userDetails.getUsername());
        login.setPassword(userDetails.getPassword());
        login.setRole(userDetails.getAuthorities().toArray()[0].toString());
		return login;
	}
	
	
	@GetMapping("/addCredentials/{userDetails}")
	public Login addCredentials(@PathVariable String userDetails)
	{
		Login login = new Login();
		ObjectMapper mapper = new ObjectMapper();
		try {
			@SuppressWarnings("unchecked")
			Map<String, String> credentials = mapper.readValue(userDetails, Map.class);
			login.setUserId(credentials.get("userId"));
			login.setUserName(credentials.get("userName"));
			login.setPassword(credentials.get("password"));
			login.setRole(credentials.get("role"));
		} catch (JsonMappingException e) {
			logger.info("Exception while MAPPING the Json String");
		} catch (JsonProcessingException e) {
			logger.info("Exception while PROCESSING the Json String");
		}
		return loginService.addCredentials(login);
		
	}
}
