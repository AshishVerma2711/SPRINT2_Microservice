package com.capgemini.go.product.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestTemplate;

import com.capgemini.go.product.dao.ProductRepository;
import com.capgemini.go.product.dto.ProductDTO;
import com.capgemini.go.product.entity.Product;
import com.capgemini.go.product.exception.DuplicateException;
import com.capgemini.go.product.exception.NotFoundException;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository productRepo;
	
	@Autowired
	RestTemplate restTemplate;

	@Override
	public List<ProductDTO> getProductList() {
		List<ProductDTO> productDtoList = new ArrayList<>();
		List<Product> productList = productRepo.findAll();
		for (Product product : productList) {
			productDtoList.add(new ProductDTO(product));
		}
		productList.clear();
		if (!productDtoList.isEmpty()) {
			return productDtoList;
		} else {
			throw new NotFoundException("Product List is empty");
		}
	}
	@Override
	public ProductDTO getProductById(String productId) {
		
		return new ProductDTO(productRepo.findById(productId).orElse(new Product()));
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public ProductDTO addProduct(ProductDTO product) {
		int tempNumber = productRepo.getAllProductId().size();
		String tempString = productRepo.getAllProductId().get(tempNumber - 1);
		tempNumber = Integer.parseInt(tempString.substring(1)) + 1;
		tempString = "P" + tempNumber;
		product.setProductId(tempString);

		if (productRepo.findByProductName(product.getProductName()) == null)
			return new ProductDTO(productRepo.save(new Product(product)));
		else
			throw new DuplicateException("Product name is already present of the same manufacture");

	}

	@Override
	public ProductDTO getProduct(String productName) {
		if (productRepo.findByProductName(productName) != null) {
			return new ProductDTO(productRepo.findByProductName(productName));
		} else {
			throw new NotFoundException("Product name is not found");
		}

	}

	@Override
	public ProductDTO updateProduct(String productId, ProductDTO product) {
		if (productRepo.existsById(productId))
			return new ProductDTO(productRepo.save(new Product(product)));
		else
			throw new NotFoundException("Product Id is not present");

	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED)
	public void deleteProductById(String productId) {
		if (productRepo.existsById(productId)) {
			productRepo.deleteById(productId);
			restTemplate.delete("http://product-image-service/image/"+productId);
		}
		else
			throw new NotFoundException("Product Id is not found");

	}

	public List<ProductDTO> getProductsList(List<String> productIdsList) {
		List<ProductDTO> productsList = new ArrayList<>();
		for (String productId : productIdsList) {
			Optional<Product> product=productRepo.findById(productId);
			if (product.isPresent()) {
				productsList.add(new ProductDTO(product.get()));
			} else {
				throw new NotFoundException("Product Id is not found" + productId);
			}
		}
		return productsList;
	}
	
	@Override
	public double getPriceByProductId(String productId) {
		if(productRepo.existsById(productId))
		{
			return productRepo.getPriceByProductId(productId);
		}
		else {
			throw new NotFoundException("Product Id not found"+productId);
		}
	}
	
	@Override
	public List<ProductDTO> searchProducts(String productName) {

		List<ProductDTO> productDtoList = new ArrayList<>();
		List<Product> productList = productRepo.searchProducts(productName);
		for (Product product : productList) {
			productDtoList.add(new ProductDTO(product));
		}
		if (!productDtoList.isEmpty()) {
			return productDtoList;
		} else {
			throw new NotFoundException("Product List is empty");
		}
		
		
	}


}
