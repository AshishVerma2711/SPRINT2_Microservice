package com.capgemini.go.product.service;

import static org.assertj.core.api.Assertions.assertThat;
import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.capgemini.go.product.dto.ProductDTO;
import com.capgemini.go.product.exception.DuplicateException;
import com.capgemini.go.product.exception.NotFoundException;

@SpringBootTest
class ProductServiceImplTest {

	@Autowired
	ProductService productService;

	@Test
	void getProductListPass() {
		assertThat(productService.getProductList()).isNotEmpty();
	}

	@Test
	void addProductPass() {
		ProductDTO product = new ProductDTO("Short put", "Baseball2", "Round in shape", 500, "Cosco");
		assertThat(productService.addProduct(product)).isNotNull();
		productService.deleteProductById("P10005");

	}

	@Test
	void addProductException() {
		ProductDTO product = new ProductDTO("Cricket Bat", "Cricket", "Square in shape", 500, "Addidas");
		assertThrows(DuplicateException.class, () -> {
			productService.addProduct(product);
		});

	}

	@Test
	void updateProductPass() {
		ProductDTO product = new ProductDTO("P10001", "Football", "Football", "Round in shape", 500, "Cosco");
		assertThat(productService.updateProduct("P10001", product)).isNotNull();

	}

	@Test
	void updateProductException() {
		ProductDTO product = new ProductDTO("P10008", "Baseball", "Baseball", "Round in shape", 500, "Cosco");
		assertThrows(NotFoundException.class, () -> {
			productService.updateProduct("P10008", product);
		});

	}

	@Test
	void deleteProductPass() {
		ProductDTO product = new ProductDTO("HandBall", "Handball", "Round in shape", 500, "Cosco");
		productService.addProduct(product);
		productService.deleteProductById("P10005");
		assertThat(productService.getProductList()).doesNotContain(product);
	}

	@Test
	void deleteProductException() {
		assertThrows(NotFoundException.class, () -> {
			productService.deleteProductById("P10006");
		});
	}

	@Test
	void getProductPass() {
		assertThat(productService.getProduct("Cricket Bat")).isNotNull();

	}

	@Test
	void getProductException() {
		assertThrows(NotFoundException.class, () -> {
			productService.getProduct("Badminton");
		});
	}
	
	@Test
	void getProductsListPass()
	{
		ArrayList<String> list=new ArrayList<>();
		list.add("P10001");
		list.add("P10002");
		assertThat(productService.getProductsList(list)).isNotEmpty();
	}
	
	@Test
	void getProductsListException()
	{
		ArrayList<String> list=new ArrayList<>();
		list.add("P10001");
		list.add("P10007");
		assertThrows(NotFoundException.class, () -> {
			productService.getProductsList(list);
		});
	}

}
