package com.capgemini.go.dto;

import java.io.Serializable;
import java.util.Objects;

import javax.persistence.Column;
import javax.persistence.Embeddable;

@Embeddable
public class CartId implements Serializable {
	@Column(name = "user_id")
	private String userId;
	
	public String toString() {
		return "CartId  [userId=" + userId + ", productId=" + productId + "]";
	}
	
	@Column(name = "product_id")
	private String productId;
	
	
	
	public CartId() {
	}
	
	public CartId(String userId, String productId) {
		
		this.userId = userId;
		this.productId = productId;
	}
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getProductId() {
		return productId;
	}
	public void setProductId(String productId) {
		this.productId = productId;
	}

	@Override
	public int hashCode() {
		return Objects.hash(this.productId,this.userId);
	}

	@Override
	public boolean equals(Object obj) {
		CartId cart=(CartId)obj;
		return this.getUserId().equals(cart.getUserId())&&this.getProductId().equals(cart.getProductId());	}
	
	
 
}
