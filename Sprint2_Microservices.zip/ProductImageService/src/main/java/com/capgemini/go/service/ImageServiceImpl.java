package com.capgemini.go.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.go.dao.ImageRepository;
import com.capgemini.go.entities.Image;

@Service
public class ImageServiceImpl implements ImageService {

	@Autowired
	ImageRepository imgRepo;
	
	@Override
	public Image getImage(String productId) {
		if(!imgRepo.existsById(productId)) {
			return imgRepo.findById("default").get();
			}
			else
			{
			return imgRepo.findById(productId).get();
			}
	}

	@Override
	public Image storeImage(Image img) {
		return imgRepo.save(img);
	}

	@Override
	public boolean deleteImage(String productId) {
		imgRepo.deleteById(productId);
		return true;
	}

}
