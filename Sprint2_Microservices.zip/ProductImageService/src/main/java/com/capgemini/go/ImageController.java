package com.capgemini.go;

import java.io.IOException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.capgemini.go.entities.Image;
import com.capgemini.go.service.ImageService;

@RestController
@CrossOrigin("*")
public class ImageController {
	
	@Autowired
	ImageService imgService;
	
	

	@GetMapping(value = "/image/{productId}")
	public ResponseEntity<Image> getImage(@PathVariable("productId")String productId)
	{		System.out.println("Image for id "+productId);
			return new ResponseEntity<>(imgService.getImage(productId),HttpStatus.OK);
	}
	
	@PostMapping(value="/addImage/{productId}",consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
	public ResponseEntity<Image> saveImage(@RequestParam("image") MultipartFile file,@PathVariable("productId") String productId) throws IOException
	{
		System.out.println("ADD Image for id "+productId);
		return new ResponseEntity<>(imgService.storeImage(new Image(productId,file.getBytes())),HttpStatus.OK);
	}
	
	@DeleteMapping(value = "/image/{productId}")
	public ResponseEntity<Boolean> deleteImage(@PathVariable("productId")String productId)
	{		System.out.println("Delete image for id "+productId);
			return new ResponseEntity<>(imgService.deleteImage(productId),HttpStatus.OK);
	}
	
}
