package com.capgemini.go.service;

import com.capgemini.go.entities.Image;

public interface ImageService {
	
	public Image getImage(String productId);
	public Image storeImage(Image img);
	public boolean deleteImage(String productId); 
}
