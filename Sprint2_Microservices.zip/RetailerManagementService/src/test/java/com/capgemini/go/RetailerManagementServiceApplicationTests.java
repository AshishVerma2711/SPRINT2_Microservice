package com.capgemini.go;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RetailerManagementServiceApplicationTests {

}
