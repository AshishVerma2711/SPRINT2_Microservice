package com.capgemini.go.dto;


public class InventoryDto {
	
	
	private InventoryId inventoryId;

	
	private int units;

	public InventoryId getProductDto() {
		return inventoryId;
	}

	public void setProductDto(InventoryId productDto) {
		this.inventoryId = productDto;
	}

	public int getUnits() {
		return units;
	}

	public void setUnits(int units) {
		this.units = units;
	}

	public InventoryDto(InventoryId inventoryId, int units) {
		super();
		this.inventoryId = inventoryId;
		this.units = units;
	}

	public InventoryDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public String toString() {
		return "InventoryDto [productDto=" + inventoryId + ", units=" + units + "]";
	}


	
}
